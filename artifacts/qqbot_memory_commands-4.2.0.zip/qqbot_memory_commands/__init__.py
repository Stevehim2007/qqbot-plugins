"""Standalone deterministic memory management commands for AstrBot."""

__version__ = "4.2.0"
