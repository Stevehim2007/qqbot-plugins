"""Standalone deterministic memory/session/persona command plugin.

One handler owns ``/记忆`` and every registered root alias.  It suppresses the
default model, reads plugin settings only from AstrBot's injected config, and
forwards canonical operations to the fixed ABI-v1 provider.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star

from . import aux, cards, commands, contracts, memory_commands, wrapup
from .backend import AstrBotBackend
from .provider import MemoryCommandsProvider, cancel_pending_confirmation
from .store import OperationStore

_PROVIDER_ID = "qqbot_memory_commands"
_REGISTRY_ATTR = "_qqbot_memory_provider_registry"
_FALLBACK_REGISTRIES: dict[int, contracts.ProviderRegistry] = {}

_PROVIDER_METHODS = {
    ("memory", "view"): "memory_read",
    ("memory", "search"): "memory_search",
    ("memory", "add"): "memory_add",
    ("memory", "preview_clear"): "memory_preview_clear",
    ("memory", "confirm"): "memory_confirm_clear",
    ("session", "status"): "session_read",
    ("session", "read"): "session_read",
    ("session", "open"): "session_open",
    ("session", "switch"): "session_switch",
    ("session", "reset"): "session_reset",
    ("persona", "list"): "persona_list",
    ("persona", "switch"): "persona_switch",
    ("persona", "bind"): "persona_bind",
}

_LEGACY_MEMORY_ACTIONS = {"status", "delete", "forget", "tidy"}


def _plugin_config(config: Any) -> Mapping[str, Any]:
    """Return the injected plugin config as a mapping (never global config)."""

    if isinstance(config, Mapping):
        return config
    try:
        converted = dict(config)
    except Exception:  # noqa: BLE001 - malformed injected config means disabled
        return {}
    return converted


def _event_text(event: AstrMessageEvent) -> str:
    return str(getattr(event, "message_str", "") or "")


def _stop_event(event: AstrMessageEvent) -> None:
    try:
        event.stop_event()
    except Exception:  # noqa: BLE001 - shutdown must not mask the reply path
        pass


def _global_config(context: Any) -> Mapping[str, Any]:
    try:
        config = context.get_config()
        if isinstance(config, Mapping):
            return config
    except Exception:  # noqa: BLE001 - optional legacy Context API
        pass
    return {}


def _build_backend(context: Any, config: Mapping[str, Any]) -> AstrBotBackend:
    """Resolve optional public APIs only; tests may monkeypatch this function."""

    memory_core = memory_commands.load_core_memory()
    memory_service = None
    if memory_core is not None and callable(
        getattr(memory_core, "get_memory_service", None)
    ):
        try:
            memory_service = memory_core.get_memory_service(_global_config(context))
        except Exception:  # noqa: BLE001 - memory remains dependency_missing
            memory_service = None
    return AstrBotBackend(
        memory_service=memory_service,
        conversation_manager=getattr(context, "conversation_manager", None),
        persona_manager=getattr(context, "persona_manager", None),
    )


def _cards_path() -> str:
    """Use the same plugin data directory as the ABI ledger."""

    ledger = _store_path()
    if ledger == ":memory:":
        return ":memory:"
    return str(Path(ledger).with_name("memory_cards.db"))


def _store_path() -> str:
    """Use the public StarTools data directory when available."""

    try:
        from astrbot.api.star import StarTools  # noqa: WPS433 - optional runtime

        getter = getattr(StarTools, "get_data_dir", None)
        if callable(getter):
            data_dir = Path(
                getter(plugin_name="qqbot_memory_commands")
            ).expanduser()
            data_dir.mkdir(parents=True, exist_ok=True)
            return str(data_dir / "contracts.sqlite3")
    except Exception:  # noqa: BLE001 - in-memory ledger is the safe fallback
        pass
    configured = str(os.environ.get("QQBOT_MEMORY_LEDGER_PATH") or "").strip()
    return configured or ":memory:"


def _build_store(context: Any, config: Mapping[str, Any]) -> OperationStore:
    # Deliberately never use backend.store_id as a filesystem path.
    return OperationStore(_store_path())


def _registry_for_context(context: Any) -> contracts.ProviderRegistry:
    registry = getattr(context, _REGISTRY_ATTR, None)
    if isinstance(registry, contracts.ProviderRegistry):
        return registry
    registry = contracts.ProviderRegistry()
    try:
        setattr(context, _REGISTRY_ATTR, registry)
        return registry
    except Exception:  # noqa: BLE001 - retain one process-local registry
        key = id(context)
        existing = _FALLBACK_REGISTRIES.get(key)
        if isinstance(existing, contracts.ProviderRegistry):
            return existing
        _FALLBACK_REGISTRIES[key] = registry
        return registry


class MemoryCommandsPlugin(Star):
    """One handler for ``/记忆`` plus session/persona command aliases."""

    def __init__(
        self,
        context: Context,
        config: Mapping[str, Any] | None = None,
    ):
        super().__init__(context)
        self.config = _plugin_config(config)
        # Compatibility alias for the pre-ABI standalone package draft.
        self.plugin_config = self.config
        self.backend = _build_backend(context, self.config)
        self.store = _build_store(context, self.config)
        card_path = _cards_path()
        self.card_store = cards.CardStore(card_path) if card_path != ":memory:" else None
        self._card_turns: dict[str, list[dict[str, str]]] = {}
        self._card_revisions: dict[str, int] = {}
        self._card_phase_counts: dict[str, int] = {}
        self._card_full_counts: dict[str, int] = {}
        self._aux_guard = aux.AuxGuard(
            daily_limit=int(self.config.get("cards_llm_daily_limit", 50) or 50),
            circuit_errors=int(self.config.get("cards_llm_circuit_errors", 3) or 3),
        )
        self.provider = MemoryCommandsProvider(
            self.backend,
            self.store,
            config=self.config,
        )
        self.registry = _registry_for_context(context)
        self.provider_id = self.registry.register(
            self.provider,
            provider_id=_PROVIDER_ID,
        )
        self.registry.mark_ready(
            self.provider_id,
            ready=bool(getattr(self.backend, "ready", False)),
        )
        self._terminated = False

    def _capability_enabled(self, event: AstrMessageEvent) -> bool:
        """Return False only when safe_tools explicitly disables memory commands."""
        try:
            getter = getattr(self.context, "get_registered_star", None)
            meta = getter("qqbot_safe_tools") if callable(getter) else None
            if meta is None:
                return True
            star = getattr(meta, "star_cls", None) or meta
            policy_fn = getattr(star, "policy_effective", None)
            if not callable(policy_fn):
                return True
            private = False
            try:
                private = bool(event.is_private_chat())
            except Exception:
                private = False
            group_id = ""
            try:
                group_id = str(event.get_group_id() or "").strip()
            except Exception:
                group_id = ""
            sender_id = ""
            try:
                sender_id = str(event.get_sender_id() or "").strip()
            except Exception:
                sender_id = ""
            policy = policy_fn(
                "qqbot_memory_commands",
                group_id=None if private else (group_id or None),
                user_id=sender_id or None,
                is_private=private,
            )
            return not isinstance(policy, dict) or bool(policy.get("enabled", True))
        except Exception:
            return True

    def _platform_namespace(self, event: AstrMessageEvent) -> str:
        origin = str(getattr(event, "unified_msg_origin", "") or "")
        lowered = origin.casefold()
        if "qq_official" in lowered or "qqbot-official" in lowered:
            return "qq_official"
        if "qqbot-onebot" in lowered:
            return "onebot"
        return "default"

    def _card_scope(self, event: AstrMessageEvent) -> str:
        platform = self._platform_namespace(event)
        try:
            private = bool(event.is_private_chat())
        except Exception:  # noqa: BLE001
            private = False
        prefix = "" if platform == "default" else f"{platform}:"
        if private:
            sender = str(getattr(event, "get_sender_id", lambda: "")() or "").strip()
            return f"user:{prefix}{sender}" if sender else ""
        group = str(getattr(event, "get_group_id", lambda: "")() or "").strip()
        if not group:
            return ""
        if bool(self.config.get("cards_group_member_enabled", False)):
            sender = str(getattr(event, "get_sender_id", lambda: "")() or "").strip()
            if sender:
                return f"group_member:{prefix}{group}:{sender}"
        return f"group:{prefix}{group}"

    async def _cards_reply(self, event: AstrMessageEvent) -> str:
        if self.card_store is None:
            return "记忆卡片存储不可用。"
        scope = self._card_scope(event)
        if not scope:
            return "无法识别当前会话，不能读取记忆卡片。"
        stats = self.card_store.stats(scope=scope)
        active = int(stats.get("active", 0))
        archived = int(stats.get("archived", 0))
        text = f"记忆卡片：活跃 {active} 张，归档 {archived} 张。当前 scope：{scope}。"
        state = self.card_store.get_session_state(scope)
        if state:
            phase = str(state.get("phase_summary") or "").strip()
            if phase:
                text += f" 阶段摘要：{phase}"
            topics = state.get("open_topics") or []
            if topics:
                text += " 未完成话题：" + "；".join(str(item) for item in topics[:2])
        return text

    @filter.on_llm_request()
    async def inject_memory_cards(self, event: AstrMessageEvent, req: Any) -> None:
        """Inject a bounded, explicitly untrusted card block into prompts."""

        if not bool(self.config.get("cards_inject_enabled", True)):
            return
        if self.card_store is None:
            return
        scope = self._card_scope(event)
        if not scope:
            return
        try:
            max_cards = max(0, min(8, int(self.config.get("cards_max_cards", 4) or 4)))
            max_chars = max(120, min(1200, int(self.config.get("cards_max_chars", 480) or 480)))
            query = str(getattr(event, "message_str", "") or "").strip()
            actor_id = str(getattr(event, "get_sender_id", lambda: "")() or "").strip()
            try:
                persona_id = str(event.get_extra("qqbot_core_reply_persona_id", "") or "").strip()
            except Exception:  # noqa: BLE001
                persona_id = ""
            selected = cards.select_for_prompt(
                self.card_store,
                scope=scope,
                max_cards=max_cards,
                max_chars=max_chars,
                query=query,
                persona_id=persona_id,
                actor_id=actor_id,
            )
            for card in selected:
                if str(card.get("kind") or "") == "purpose":
                    try:
                        self.card_store.record_purpose_usage(
                            group_id=scope,
                            purpose_id=str(card.get("id") or ""),
                            turn_id=str(event.get_extra("qqbot_core_reply_turn_id", "") or ""),
                            result="offered",
                        )
                    except Exception:
                        pass
            block = cards.render_prompt_block(selected, max_chars=max_chars)
            if not block:
                return
            prompt = str(getattr(req, "system_prompt", "") or "")
            if "[memory_cards]" in prompt:
                return
            req.system_prompt = prompt + ("\n" if prompt else "") + block
        except Exception:  # noqa: BLE001 - card injection must never break chat
            return

    async def _wrapup_reply(self, event: AstrMessageEvent) -> str:
        if self.card_store is None:
            return "记忆卡片存储不可用。"
        scope = self._card_scope(event)
        if not scope:
            return "无法识别当前会话，不能生成收尾卡片。"
        buffer = self._card_turns.get(scope, [])
        if not buffer:
            return "当前会话还没有可收尾的对话。"
        revision = int(self._card_revisions.get(scope, 0)) + 1
        self._card_revisions[scope] = revision
        plan = wrapup.preview(
            conversation_id=scope,
            session_revision=revision,
            scope=scope,
            messages=buffer,
            purpose_enabled=bool(self.config.get("cards_purpose_enabled", False)),
        )
        result = wrapup.apply_plan(self.card_store, plan)
        return f"记忆收尾完成：生成 {len(result.get('cards', []))} 张卡片，revision={revision}。"

    @filter.on_llm_response()
    async def record_memory_turn(self, event: AstrMessageEvent, resp: Any) -> None:
        """Buffer turns and emit a deterministic phase wrap-up every N turns."""

        if self.card_store is None:
            return
        if not bool(self.config.get("cards_auto_wrapup_enabled", True)):
            return
        scope = self._card_scope(event)
        if not scope:
            return
        try:
            every = max(2, min(30, int(self.config.get("cards_wrapup_every_turns", 8) or 8)))
            phase_every = max(2, min(30, int(self.config.get("cards_phase_every_turns", 6) or 6)))
            text = str(getattr(event, "message_str", "") or "").strip()
            answer = str(
                getattr(resp, "completion_text", None)
                or getattr(resp, "text", None)
                or ""
            ).strip()
            if not text:
                return
            buffer = self._card_turns.setdefault(scope, [])
            buffer.append({"role": "user", "content": text})
            if answer:
                buffer.append({"role": "assistant", "content": answer})
            del buffer[:-12]
            phase_count = int(self._card_phase_counts.get(scope, 0)) + 1
            full_count = int(self._card_full_counts.get(scope, 0)) + 1
            self._card_phase_counts[scope] = phase_count
            self._card_full_counts[scope] = full_count
            revision = int(self._card_revisions.get(scope, 0)) + 1
            if full_count >= every:
                self._card_revisions[scope] = revision
                self._card_full_counts[scope] = 0
                phase_hint = ""
                if bool(self.config.get("cards_llm_aux_enabled", False)) and self._aux_guard.allow():
                    phase_hint = await aux.phase_summary(
                        self.context,
                        [str(item.get("content") or "") for item in buffer],
                        timeout=float(self.config.get("cards_llm_timeout_seconds", 8) or 8),
                    )
                    self._aux_guard.record(bool(phase_hint))
                plan = wrapup.preview(
                    conversation_id=scope,
                    session_revision=revision,
                    scope=scope,
                    messages=buffer,
                    purpose_enabled=bool(self.config.get("cards_purpose_enabled", False)),
                    phase_hint=phase_hint,
                )
                wrapup.apply_plan(self.card_store, plan)
                self.card_store.archive_decayed(scope=scope)
                self.card_store.sweep(scope=scope)
            elif phase_count >= phase_every:
                self._card_revisions[scope] = revision
                self._card_phase_counts[scope] = 0
                plan = wrapup.phase_preview(
                    conversation_id=scope,
                    session_revision=revision,
                    scope=scope,
                    messages=buffer,
                )
                wrapup.apply_phase(self.card_store, plan)
        except Exception:  # noqa: BLE001 - memory side effects must not break chat
            return

    # ------------------------------------------------------------------
    # command handler
    # ------------------------------------------------------------------
    @filter.command(
        "记忆",
        alias={"记忆管理", "memory", "会话", "session", "人格", "persona"},
        priority=110,
    )
    async def memory_command(self, event: AstrMessageEvent):
        """Answer one fixed management command without the main model."""

        reply = memory_commands.HANDLER_FAILED_REPLY
        try:
            # AstrBot's True flag means "handled; do not call the default LLM".
            event.should_call_llm(True)
            if not self._capability_enabled(event):
                return
            reply = await self._dispatch(event)
        except Exception:  # noqa: BLE001 - bounded Chinese failure, no traceback
            reply = memory_commands.HANDLER_FAILED_REPLY

        try:
            yield event.plain_result(reply)
        except Exception:  # noqa: BLE001 - transport failure cannot be re-sent
            pass
        finally:
            _stop_event(event)

    async def _dispatch(self, event: AstrMessageEvent) -> str:
        parsed = commands.parse_management_command(_event_text(event))
        options = memory_commands.options_from_config(self.config)
        if parsed.action in {"empty", "help"}:
            return memory_commands._bounded(
                commands.help_text(parsed.root or "memory"),
                options,
            )
        if parsed.action == "parse_error":
            return memory_commands._bounded(
                f"参数错误：{parsed.error}。{commands.help_text(parsed.root)}",
                options,
            )
        if parsed.action == "unknown":
            return memory_commands._bounded(
                f"未知命令。{commands.help_text(parsed.root or 'memory')}",
                options,
            )

        if parsed.root == "memory" and parsed.action == "cards":
            return self._cards_reply(event)
        if parsed.root == "memory" and parsed.action == "wrapup":
            return await self._wrapup_reply(event)

        if parsed.root == "memory" and parsed.action == "cancel":
            return self._cancel_confirmation(event, parsed, options)
        if parsed.root == "memory" and parsed.action in _LEGACY_MEMORY_ACTIONS:
            return self._legacy_reply(event, options)
        if parsed.root == "memory" and parsed.action == "search":
            if not self._provider_ready() and "scope" not in dict(parsed.options):
                return self._legacy_reply(event, options)

        return await self._provider_reply(event, parsed, options)

    def _provider_ready(self) -> bool:
        return bool(self.registry.is_ready(self.provider_id))

    def _legacy_reply(
        self,
        event: AstrMessageEvent,
        options: memory_commands.Options,
    ) -> str:
        return memory_commands.handle_text(
            text=_event_text(event),
            prefixes=("/",),
            event=event,
            context=self.context,
            options=options,
            core=memory_commands.load_core_memory(),
        )

    def _cancel_confirmation(
        self,
        event: AstrMessageEvent,
        parsed: commands.ParsedManagementCommand,
        options: memory_commands.Options,
    ) -> str:
        requested_scope = "group" if not bool(
            getattr(event, "is_private_chat", lambda: True)()
        ) else "user"
        context = commands.build_request_context(
            event,
            self.config,
            capability="memory.confirm_clear",
            requested_scope=requested_scope,
        )
        args, error = commands.build_provider_args(parsed, context)
        if error:
            return memory_commands._bounded(error, options)
        token = str(args.get("confirmation_token") or "")
        result = cancel_pending_confirmation(self.store, context, token)
        return memory_commands._bounded(
            commands.render_command_result(
                parsed,
                result,
                content_chars=options.content_chars,
                max_reply_chars=options.max_reply_chars,
                max_items=options.max_results,
            ),
            options,
        )

    async def _provider_reply(
        self,
        event: AstrMessageEvent,
        parsed: commands.ParsedManagementCommand,
        options: memory_commands.Options,
    ) -> str:
        initial_scope = "group" if not bool(
            getattr(event, "is_private_chat", lambda: True)()
        ) else "user"
        if parsed.root in {"session", "persona"}:
            initial_scope = "conversation" if parsed.root == "session" else "persona"
        context = commands.build_request_context(
            event,
            self.config,
            capability=commands.command_capability(parsed),
            requested_scope=initial_scope,
        )
        args, error = commands.build_provider_args(parsed, context)
        if error:
            return memory_commands._bounded(error, options)
        context = commands.build_request_context(
            event,
            self.config,
            capability=commands.command_capability(parsed),
            requested_scope=str(args.get("scope") or initial_scope),
        )
        method = _PROVIDER_METHODS.get((parsed.root, parsed.action))
        if method is None:
            return memory_commands._bounded(
                f"未知命令。{commands.help_text(parsed.root)}",
                options,
            )
        result = await getattr(self.provider, method)(context, args)
        return memory_commands._bounded(
            commands.render_command_result(
                parsed,
                result,
                content_chars=options.content_chars,
                max_reply_chars=options.max_reply_chars,
                max_items=options.max_results,
            ),
            options,
        )

    async def terminate(self):
        """Unregister this provider and close its local ledger."""

        if self._terminated:
            return
        self._terminated = True
        try:
            self.registry.terminate(self.provider_id)
        finally:
            try:
                self.store.close()
            except Exception:  # noqa: BLE001 - termination stays best effort
                pass
