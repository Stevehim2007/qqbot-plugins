"""Deterministic conversation wrap-up for memory cards v4.

The wrap-up layer never calls a model and never writes the raw memory store; it updates the derived card/session state only.
It derives episode/open-topic cards from already available messages and uses
the card store's ``wrapup_ledger`` for idempotency.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from typing import Any

from . import cards

MAX_SUMMARY_CHARS = 240
MAX_PHASE_CHARS = 160
MAX_OPEN_TOPIC_CHARS = 120

_QUESTION_RE = re.compile(r"[?？]\s*$")
_SPACE_RE = re.compile(r"\s+")
_MENTION_RE = re.compile(r"@[^\s()]{1,64}\(\d{3,}\)")
_MARKDOWN_RE = re.compile(r"!?\[[^\]]*\]\([^)]*\)")
_BAD_MARKERS = ("[[NO_REPLY]]", "mqqapi://", "ComponentType.")
_DURABLE_RE = re.compile(
    r"我的名字|我叫|我喜欢|我不喜欢|我讨厌|我爱|我住在|我在.{0,12}(?:工作|上班|上学)|"
    r"我养|我每天|我通常|我习惯|记住|以后|下次|答应|计划|想要|希望|生日|过敏|"
    r"工作|上班|上学|住在"
)
_SENTENCE_RE = re.compile(r"[^。！？!?；;\n]+")


def _clean_fragment(text: str) -> str:
    """Drop transport noise before a message becomes a memory card."""

    value = str(text or "")
    if any(marker in value for marker in _BAD_MARKERS):
        return ""
    value = _MARKDOWN_RE.sub("", value)
    value = _MENTION_RE.sub("", value)
    value = _SPACE_RE.sub(" ", value).strip()
    if len(value) < 2:
        return ""
    return value[:180].rstrip()


def _content(message: Any) -> str:
    if isinstance(message, str):
        return message.strip()
    if isinstance(message, Mapping):
        return str(message.get("content") or message.get("text") or "").strip()
    return str(getattr(message, "content", "") or "").strip()


def _role(message: Any) -> str:
    if isinstance(message, Mapping):
        return str(message.get("role") or "user").strip().lower()
    return str(getattr(message, "role", "user") or "user").strip().lower()


def _compact(text: str, max_chars: int) -> str:
    text = _SPACE_RE.sub(" ", str(text or "")).strip()
    if len(text) <= max_chars:
        return text
    return text[: max(0, max_chars - 1)].rstrip() + "…"


def summarize_messages(messages: Iterable[Any], *, max_chars: int = MAX_SUMMARY_CHARS) -> str:
    """Legacy transcript formatter kept for diagnostics/backward tests.

    New episode cards do not use this: raw multi-turn transcripts made memory
    noisy.  ``durable_episode`` is the production writer.
    """

    parts: list[str] = []
    for message in list(messages)[-12:]:
        role = _role(message)
        if role not in {"user", "assistant"}:
            continue
        text = _clean_fragment(_content(message))
        if not text:
            continue
        parts.append(("用户：" if role == "user" else "助手：") + text)
    return _compact("；".join(parts), max_chars)


def durable_episode(messages: Iterable[Any], *, max_chars: int = MAX_SUMMARY_CHARS) -> str:
    """Keep only explicit, durable user facts; never store raw chat transcripts.

    Casual dialogue, assistant-only turns, questions, and transport noise are
    intentionally dropped.  This is deliberately conservative: a missed
    memory is cheaper than a polluted memory bank.
    """

    facts: list[str] = []
    seen: set[str] = set()
    for message in list(messages)[-30:]:
        if _role(message) != "user":
            continue
        text = _clean_fragment(_content(message))
        if not text:
            continue
        for sentence in _SENTENCE_RE.findall(text):
            candidate = _compact(sentence, 120).strip(" ，,。；;")
            if len(candidate) < 4 or candidate.endswith(("?", "？")):
                continue
            if not _DURABLE_RE.search(candidate):
                continue
            key = candidate.casefold()
            if key in seen:
                continue
            seen.add(key)
            facts.append(candidate)
            if len(facts) >= 3:
                break
        if len(facts) >= 3:
            break
    return _compact("；".join(facts), max_chars)


def _user_phase(messages: Iterable[Any], *, max_chars: int = MAX_PHASE_CHARS) -> str:
    """A short phase line with no assistant echo or transport noise."""

    parts: list[str] = []
    for message in list(messages)[-6:]:
        if _role(message) != "user":
            continue
        text = _clean_fragment(_content(message))
        if text:
            parts.append(text)
    return _compact("；".join(parts), max_chars)


def phase_summary(messages: Iterable[Any], *, max_chars: int = MAX_PHASE_CHARS) -> str:
    """Short phase summary for the last six visible turns."""

    return _compact(summarize_messages(list(messages)[-6:], max_chars=max_chars), max_chars)


def last_open_topic(messages: Iterable[Any], *, max_chars: int = MAX_OPEN_TOPIC_CHARS) -> str:
    for message in reversed(list(messages)[-20:]):
        if _role(message) != "user":
            continue
        text = _compact(_content(message), max_chars)
        if text and (_QUESTION_RE.search(text) or text.endswith("吗") or "怎么" in text or "如何" in text):
            return text
    return ""


def preview(
    *,
    conversation_id: str,
    session_revision: int,
    scope: str,
    messages: Iterable[Any],
    group_id: str = "",
    persona_id: str = "",
    actor_id: str = "",
    purpose_enabled: bool = False,
    phase_hint: str = "",
    episode_hint: str = "",
    episode_enabled: bool = True,
) -> dict[str, Any]:
    """Return a deterministic wrap-up plan; no persistence."""

    visible = list(messages)
    summary = _clean_fragment(str(episode_hint or "")) if str(episode_hint or "").strip() else ""
    if not summary:
        summary = durable_episode(visible)
    if summary:
        summary = _compact(summary, MAX_SUMMARY_CHARS)
    phase = _user_phase(visible)
    open_topic = last_open_topic(visible)
    planned: list[dict[str, Any]] = []
    if summary and episode_enabled:
        planned.append(
            {
                "kind": "episode",
                "subtype": "session_summary",
                "title": "会话摘要",
                "content": summary,
                "importance": 0.45,
                "confidence": 0.6,
            }
        )
    if open_topic:
        planned.append(
            {
                "kind": "open_topic",
                "subtype": "",
                "title": "未完成话题",
                "content": open_topic,
                "importance": 0.55,
                "confidence": 0.55,
            }
        )
    if purpose_enabled and open_topic:
        planned.append(
            {
                "kind": "purpose",
                "subtype": "",
                "title": "待办目的",
                "content": _compact("跟进：" + open_topic, MAX_OPEN_TOPIC_CHARS),
                "importance": 0.5,
                "confidence": 0.5,
            }
        )
    return {
        "conversation_id": str(conversation_id),
        "session_revision": int(session_revision),
        "scope": scope,
        "group_id": str(group_id or ""),
        "persona_id": str(persona_id or ""),
        "actor_id": str(actor_id or ""),
        "phase_summary": _compact(phase_hint, MAX_PHASE_CHARS) if phase_hint else summary,
        "open_topic": open_topic,
        "cards": planned,
    }


def phase_preview(
    *,
    conversation_id: str,
    session_revision: int,
    scope: str,
    messages: Iterable[Any],
    group_id: str = "",
    persona_id: str = "",
    actor_id: str = "",
) -> dict[str, Any]:
    """Lightweight six-turn phase state; does not create prompt cards."""

    visible = list(messages)
    return {
        "conversation_id": str(conversation_id),
        "session_revision": int(session_revision),
        "scope": scope,
        "group_id": str(group_id or ""),
        "persona_id": str(persona_id or ""),
        "actor_id": str(actor_id or ""),
        "phase_summary": _user_phase(visible),
        "open_topic": last_open_topic(visible),
        "cards": [],
        "kind": "phase",
    }


def apply_phase(store: cards.CardStore, plan: Mapping[str, Any], *, now: float | None = None) -> dict[str, Any]:
    """Persist a phase update without creating duplicate episode cards."""

    conversation_id = str(plan.get("conversation_id") or "").strip()
    revision = int(plan.get("session_revision") or 0)
    if not conversation_id:
        raise cards.CardError("conversation_id 不能为空。")
    previous = store.get_wrapup(conversation_id, revision)
    if previous and previous.get("status") == "applied":
        return {"applied": False, "reason": "already_applied", "wrapup": previous}
    topic = str(plan.get("open_topic") or "")
    store.put_session_state(
        conversation_id=conversation_id,
        session_revision=revision,
        phase_summary=str(plan.get("phase_summary") or ""),
        open_topics=[topic] if topic else [],
        last_wrapup_revision=revision,
        now=now,
    )
    record = store.put_wrapup(
        conversation_id=conversation_id,
        session_revision=revision,
        status="applied",
        payload=plan,
        result={"kind": "phase"},
        kind="phase",
        trigger=str(plan.get("trigger") or "auto"),
        now=now,
    )
    store.audit(
        action="wrapup.phase",
        target_type="conversation",
        target_id=conversation_id,
        scope=str(plan.get("scope") or ""),
        after={"revision": revision},
        reason=str(plan.get("trigger") or "auto"),
        now=now,
    )
    return {"applied": True, "cards": [], "wrapup": record}


def apply_plan(store: cards.CardStore, plan: Mapping[str, Any], *, now: float | None = None) -> dict[str, Any]:
    """Apply a preview plan exactly once for its conversation revision."""

    conversation_id = str(plan.get("conversation_id") or "").strip()
    revision = int(plan.get("session_revision") or 0)
    if not conversation_id:
        raise cards.CardError("conversation_id 不能为空。")
    previous = store.get_wrapup(conversation_id, revision)
    if previous and previous.get("status") == "applied":
        return {"applied": False, "reason": "already_applied", "wrapup": previous}
    created: list[dict[str, Any]] = []
    try:
        for item in plan.get("cards") or []:
            if not isinstance(item, Mapping):
                continue
            kind = str(item.get("kind") or "episode")
            content = str(item.get("content") or "")
            if kind == "episode":
                content = _clean_fragment(content)
                if not content:
                    continue
            card = store.create(
                scope=str(plan.get("scope") or "conversation"),
                content=content,
                kind=kind,
                subtype=str(item.get("subtype") or ""),
                title=str(item.get("title") or ""),
                group_id=str(plan.get("group_id") or ""),
                persona_id=str(plan.get("persona_id") or ""),
                actor_id=str(plan.get("actor_id") or ""),
                importance=float(item.get("importance") or 0.5),
                confidence=float(item.get("confidence") or 0.5),
                source_kind="wrapup",
                source_turn_ids=plan.get("source_turn_ids") or (),
                source_key=str(item.get("source_key") or ""),
                evidence={"source": "wrapup", "conversation_id": conversation_id, "session_revision": revision},
                now=now,
            )
            created.append(card)
        purpose = next((item for item in plan.get("cards") or [] if str(item.get("kind")) == "purpose"), None)
        store.put_session_state(
            conversation_id=conversation_id,
            session_revision=revision,
            phase_summary=str(plan.get("phase_summary") or ""),
            open_topics=[str(plan.get("open_topic") or "")] if plan.get("open_topic") else [],
            purpose={"text": str(purpose.get("content") or ""), "confidence": float(purpose.get("confidence") or 0.5)} if purpose else {},
            last_wrapup_revision=revision,
            now=now,
        )
        record = store.put_wrapup(
            conversation_id=conversation_id,
            session_revision=revision,
            status="applied",
            payload=plan,
            result={"card_ids": [card["id"] for card in created]},
            kind="wrapup",
            trigger=str(plan.get("trigger") or "auto"),
            now=now,
        )
        store.audit(
            action="wrapup.apply",
            target_type="conversation",
            target_id=conversation_id,
            scope=str(plan.get("scope") or ""),
            after={"revision": revision, "card_ids": [card["id"] for card in created]},
            reason=str(plan.get("trigger") or "auto"),
            now=now,
        )
    except Exception as exc:  # noqa: BLE001 - record failure without masking it
        store.put_wrapup(
            conversation_id=conversation_id,
            session_revision=revision,
            status="failed",
            payload=plan,
            result={"error": type(exc).__name__},
            kind="wrapup",
            trigger=str(plan.get("trigger") or "auto"),
            now=now,
        )
        raise
    return {"applied": True, "cards": created, "wrapup": record}
