"""AstrBot registration/adapter entrypoint for qqbot_core_reply.

All business logic lives in the pure modules (participation, command_exclusion,
cooldown, conversation, persona, model_gateway, reply_pipeline, state,
contracts, commands).  This file only wires decorators, Context services and
AstrBot result objects.
"""

from __future__ import annotations

import asyncio
import random
import re
import time
from pathlib import Path
from typing import Any

import astrbot.api.message_components as Comp
from astrbot.api import logger

def _install_qqofficial_role_compat() -> None:
    """Preserve QQ official author.member_role on botpy GroupMessage.

    botpy 1.x only keeps member_openid in GroupMessage._User.  The nested
    _User class has a normal __dict__, unlike GroupMessage (slots), so we can
    attach the raw member_role without touching the installed package.
    """
    try:
        GroupMessage = __import__("botpy.message", fromlist=["GroupMessage"]).GroupMessage
        user_cls = getattr(GroupMessage, "_User", None)
        original = getattr(user_cls, "__init__", None) if user_cls is not None else None
        if original is None or getattr(original, "_qqbot_role_compat", False):
            return

        def _init(self, data):
            original(self, data)
            try:
                self.member_role = str((data or {}).get("member_role") or "")
            except Exception:
                pass

        setattr(_init, "_qqbot_role_compat", True)
        user_cls.__init__ = _init
    except Exception:
        return


_install_qqofficial_role_compat()
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star, StarTools

_UNMENTIONED_COMMANDS = (
    ("/天气", "qqbot_weather"),
    ("/每日运势", "qqbot_fortune"),
    ("/运势", "qqbot_fortune"),
    ("/定时", "qqbot_scheduler"),
    ("/option", "qqbot_core_reply"),
)


def _unmentioned_command_owner(text: str) -> str:
    value = str(text or "").strip().replace("／", "/")
    for prefix, plugin_id in _UNMENTIONED_COMMANDS:
        candidates = (prefix, prefix.lstrip("/"))
        for candidate in candidates:
            if value == candidate or value.startswith(candidate + " ") or value.startswith(candidate + "\t"):
                return plugin_id
    return ""

try:  # Loaded as a package by AstrBot.
    from . import command_exclusion as command_engine
    from . import contracts
    from .commands import CommandReply, CommandService
    from .config import RuntimeConfig
    from .conversation import ConversationService
    from .cooldown import CooldownGate
    from .model_gateway import ModelGateway
    from .participation import ParticipationPolicy
    from .persona import PersonaService
    from .reply_pipeline import (
        AMBIENT_EXTRA,
        ALLOW_STICKER_EXTRA,
        CANDIDATE_EXTRA,
        TEXT_EXTRA,
        CoreReplyService,
        ReplyPipeline,
    )
    from .state import RuntimeState
except ImportError:  # Loaded directly by a test harness.
    import sys as _sys

    _plugin_dir = str(Path(__file__).resolve().parent)
    if _plugin_dir not in _sys.path:
        _sys.path.insert(0, _plugin_dir)
    import command_exclusion as command_engine
    import contracts
    from commands import CommandReply, CommandService
    from config import RuntimeConfig
    from conversation import ConversationService
    from cooldown import CooldownGate
    from model_gateway import ModelGateway
    from participation import ParticipationPolicy
    from persona import PersonaService
    from reply_pipeline import (
        AMBIENT_EXTRA,
        ALLOW_STICKER_EXTRA,
        CANDIDATE_EXTRA,
        TEXT_EXTRA,
        CoreReplyService,
        ReplyPipeline,
    )
    from state import RuntimeState

PLUGIN_NAME = "qqbot_core_reply"
PLUGIN_DISPLAY_NAME = "QQ 核心回复"
PLUGIN_VERSION = "4.0.22"
PLUGIN_DIR = Path(__file__).resolve().parent
SONG_DIR = PLUGIN_DIR / "songs"
PROVIDER_ID = "core_reply"


def _platform_types() -> Any:
    adapter = getattr(filter, "PlatformAdapterType", None)
    if adapter is None:
        return None
    names = ("AIOCQHTTP", "QQOFFICIAL", "QQOFFICIAL_WEBHOOK")
    values = [getattr(adapter, name) for name in names if hasattr(adapter, name)]
    if not values:
        return None
    combined = values[0]
    for value in values[1:]:
        try:
            combined = combined | value
        except TypeError:
            break
    return combined


_PLATFORM_TYPES = _platform_types()

# User-facing commands only.  Deliberately excludes instance/plugin settings,
# admin-only group controls, and anything that exposes internal configuration.
OPTION_COMMANDS: tuple[dict[str, Any], ...] = (
    {
        "name": "option",
        "aliases": ("插件用法", "用法"),
        "usage": "/option [指令名]",
        "summary": "查看可用指令；带指令名时显示详细用法",
        "detail": "直接发送 /option 会列出所有可用指令；发送 /option 指令名 查看该指令的用途、参数和示例。",
        "examples": ("/option", "/option 美食"),
        "plugin": "",
    },
    {
        "name": "记忆",
        "usage": "/记忆 [查看|添加|删除|清空] ...",
        "summary": "查看或管理本群/个人记忆",
        "detail": "按群或用户读写长期记忆；具体权限和 scope 由当前实例的记忆策略决定。",
        "examples": ("/记忆", "/记忆 查看"),
        "plugin": "qqbot_memory_commands",
    },
    {
        "name": "美食",
        "aliases": ("food", "吃什么", "饭店"),
        "usage": "/美食 [关键词] [--location 城市] [--tag 标签]",
        "summary": "搜索美食/餐厅，或按提示提交评价",
        "detail": "自然语言也可以直接说想吃什么；群策略可设置默认城市。",
        "examples": ("/美食 火锅", "/美食 烧烤 --location 长春"),
        "plugin": "qqbot_food",
    },
    {
        "name": "表情",
        "usage": "/表情 [列表|分类|状态]",
        "summary": "查看或操作本地表情包",
        "detail": "发送 /表情 列表、/表情 分类 或 /表情 状态；收藏与发送受群策略控制。",
        "examples": ("/表情 列表", "/表情 分类"),
        "plugin": "qqbot_stickers",
    },
    {
        "name": "定时",
        "usage": "/定时 HH:MM 消息 [日期段]",
        "summary": "创建每天、日期段、星期或工作日定时消息",
        "detail": "日期段支持 YYYY-MM-DD~YYYY-MM-DD；星期支持周一~周日、逗号/顿号分隔；也支持工作日/非工作日。",
        "examples": ("/定时 08:00 早安", "/定时 12:00 午饭 周一、周三", "/定时 09:00 上班 工作日"),
        "plugin": "qqbot_scheduler",
    },
    {
        "name": "每日运势",
        "aliases": ("运势", "方舟运势"),
        "usage": "/每日运势",
        "summary": "查看今日方舟风格运势",
        "detail": "按用户和日期生成确定性运势，不调用大模型，仅供娱乐。",
        "examples": ("/每日运势",),
        "plugin": "qqbot_fortune",
    },
    {
        "name": "天气",
        "usage": "/天气 城市",
        "summary": "查询城市未来 7 天天气并生成图片",
        "detail": "使用中国天气网数据，图片由 Pillow 渲染；不调用大模型。",
        "examples": ("/天气 长春",),
        "plugin": "qqbot_weather",
    },
)


class CoreReplyPlugin(Star):
    """Thin AstrBot adapter around the single reply controller."""

    def __init__(self, context: Context, config: Any = None) -> None:
        super().__init__(context)
        self.context = context
        self.config_obj = config if config is not None else {}
        self.config = RuntimeConfig(self.config_obj)
        self.state = RuntimeState(
            self.config,
            rng=random.Random(),
            clock=time.monotonic,
        )
        self._song_dir = SONG_DIR
        self.owner_token = f"{PLUGIN_NAME}:{id(self)}"

        self.participation = ParticipationPolicy(self.config, self.state)
        self.cooldown = CooldownGate(self.state)
        try:
            data_dir = Path(StarTools.get_data_dir(PLUGIN_NAME))
        except Exception:
            data_dir = None
        self.persona = PersonaService(
            context, self.config, self.state, logger, data_dir=data_dir
        )
        if data_dir is not None:
            self.state.attach_language_prefs(data_dir / "member_language_prefs.json")
        self.gateway = ModelGateway(context, self.config, self.state, self.persona)
        self.pipeline = ReplyPipeline(
            context,
            self.config,
            self.state,
            self.participation,
            self.cooldown,
            self.persona,
            self.gateway,
            self.owner_token,
        )
        self.conversation = ConversationService(context, self.config, self.persona)
        self.commands = CommandService(
            context,
            self.config,
            self.state,
            self.persona,
            self.conversation,
            self.gateway,
            song_dir_getter=lambda: self._song_dir,
            set_ready=self._set_ready,
        )
        self.service = CoreReplyService(
            self.pipeline,
            registry=None,
            owner_token=self.owner_token,
            provider_id=PROVIDER_ID,
        )
        self.registry = contracts.ensure_registry(context)
        self.service.registry = self.registry
        methods = {
            name: getattr(self.service, name)
            for name in CoreReplyService.METHOD_NAMES
        }
        enabled = self.config.bool("enabled", False)
        self.state.set_ready(enabled)
        self.descriptor = self.registry.register_provider(
            PROVIDER_ID,
            plugin_id=PLUGIN_NAME,
            capability="reply",
            abi_version=contracts.ABI_VERSION,
            owner=self.owner_token,
            methods=methods,
            owner_epoch=self.state.owner_epoch,
            ready=enabled,
            service=self.service,
        )
        self._publish_readiness(enabled)

    # ------------------------------------------------------------------
    # Compatibility properties / tiny adapter helpers
    # ------------------------------------------------------------------
    @property
    def _clock(self):
        return self.state.clock

    @_clock.setter
    def _clock(self, value):
        self.state.clock = value

    @property
    def _rng(self):
        return self.state.rng

    @_rng.setter
    def _rng(self, value):
        self.state.rng = value

    def _cfg_str(self, key: str, default: str = "") -> str:
        return self.config.string(key, default=default)

    def _memory_mode(self) -> str:
        return self.persona.memory_mode()

    def _mark_candidate(
        self,
        event: AstrMessageEvent,
        original_text: str,
        *,
        ambient: bool,
    ) -> None:
        self.pipeline.mark_candidate(event, original_text, ambient=ambient)

    def _remember_history(
        self,
        event: AstrMessageEvent,
        message_text: str,
        *,
        has_image: bool,
        has_face: bool,
    ) -> None:
        self.pipeline.remember_history(
            event,
            message_text,
            has_image=has_image,
            has_face=has_face,
        )

    def _build_option_text(self) -> str:
        return self.commands.option_text()

    def _finalize_reply(self, text: Any) -> str:
        return self.gateway.finalize_text(text)

    def _build_prompt(self, event: AstrMessageEvent, message_text: str, **kwargs: Any) -> str:
        return self.persona.build_prompt(event, message_text, **kwargs)

    def _resolve_event_persona(self, event: AstrMessageEvent):
        return self.persona.resolve_event_persona(event)

    def _group_random_eligible(self, message_text: str, components: list[Any]) -> bool:
        return self.participation.group_random_eligible(
            message_text,
            has_image=any(
                self.pipeline.is_component(item, "Image") for item in components
            ),
            has_face=any(
                self.pipeline.is_component(item, "Face") for item in components
            ),
        )

    def _ambient_group_should_participate(
        self,
        event: AstrMessageEvent,
        message_text: str,
        components: list[Any],
    ) -> bool:
        return self.participation.ambient_should_participate(
            event,
            message_text,
            has_image=any(
                self.pipeline.is_component(item, "Image") for item in components
            ),
            has_face=any(
                self.pipeline.is_component(item, "Face") for item in components
            ),
            session_key=str(getattr(event, "unified_msg_origin", "") or ""),
        )

    _ambient_should_participate = _ambient_group_should_participate

    def _command_prefixes(self, event: AstrMessageEvent) -> list[str]:
        return self.pipeline.command_prefixes(event)

    def _is_command_message(self, event: AstrMessageEvent, text: str) -> bool:
        return self.pipeline.command_match(event, text) is not None

    def _safe_tools_available(self) -> bool:
        return self.gateway.safe_tools_available()

    def _get_current_provider_id(self, event: AstrMessageEvent):
        return self.gateway.current_provider_id(event)

    def _llm_generate(self, **kwargs: Any):
        return self.gateway.llm_generate(**kwargs)

    def _collect_image_refs(self, event: AstrMessageEvent):
        return self.gateway.collect_image_refs(event)

    def _provider_image_capability(self, provider: Any):
        return self.gateway.provider_image_capability(provider)

    def _set_ready(self, enabled: bool) -> None:
        enabled = bool(enabled)
        self.state.set_ready(enabled)
        try:
            self.registry.set_ready(
                PROVIDER_ID,
                enabled,
                owner=self.owner_token,
                owner_epoch=self.state.owner_epoch,
            )
        except Exception:
            pass
        self._publish_readiness(enabled)

    def _publish_readiness(self, enabled: bool) -> None:
        for name, value in (
            ("qqbot_core_reply_ready", bool(enabled)),
            ("qqbot_core_reply_owner_epoch", self.state.owner_epoch),
            ("qqbot_reply_owner", PROVIDER_ID),
        ):
            try:
                setattr(self.context, name, value)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Main event handler (single reply path)
    # ------------------------------------------------------------------
    def _help_command_enabled(self, event: AstrMessageEvent) -> bool:
        """Read the global default plus an optional per-group policy override."""
        enabled = self.config.bool("help_command_enabled", True)
        group_id = self.persona._safe_group_id(event)
        is_private = not bool(group_id)
        policy = self.pipeline._capability_policy(
            "qqbot_core_reply",
            group_id=group_id,
            user_id=str(getattr(event, "get_sender_id", lambda: "")() or ""),
            is_private=is_private,
        )
        params = policy.get("params") if isinstance(policy, dict) else None
        if isinstance(params, dict) and "help_command_enabled" in params:
            return bool(params["help_command_enabled"])
        return bool(enabled)

    @staticmethod
    def _has_bot_mention(event: AstrMessageEvent) -> bool:
        """Return True only when the bot is actually mentioned in this event."""
        try:
            self_id = str(event.get_self_id() or "")
            if not self_id or self_id in {"qq_official", "unknown_selfid"}:
                # QQ 官方在部分群事件里不返回真实机器人 openid，只给
                # At:qq_official 占位。此时 GROUP_AT_MESSAGE_CREATE 的
                # is_at_or_wake_command 才是可靠的“被 @”信号。
                return bool(getattr(event, "is_at_or_wake_command", False))
            components = list(
                getattr(getattr(event, "message_obj", None), "message", None) or []
            )
            if not components:
                getter = getattr(event, "get_messages", None)
                components = list(getter() or []) if callable(getter) else []
            for component in components:
                if type(component).__name__ != "At":
                    continue
                if str(getattr(component, "qq", "") or "") == self_id:
                    return True
        except Exception:
            return False
        return False

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=999)
    @filter.event_message_type(filter.EventMessageType.ALL, priority=999)
    async def hard_group_mention_gate(self, event: AstrMessageEvent):
        """Drop unmentioned group messages before any business handler runs.

        This is intentionally an event gate, not a probability/decision hint:
        with participation.group_mention_only=True a group message that does
        not really mention the bot never reaches the pipeline, tools, memory
        observers, or the model. Private chats and real @ mentions pass.
        """
        try:
            if not self.config.bool("enabled", False):
                return
            # Stamp the active persona at the earliest hook so sibling memory
            # plugins (priority 118) can partition their data correctly.
            try:
                persona_id = self.persona.persona_id_for_event(event)
                _prompt, persona_name, _source = self.persona.resolve_event_persona(event)
                event.set_extra("qqbot_core_reply_persona_id", persona_id)
                event.set_extra("qqbot_core_reply_persona_name", persona_name)
            except Exception:
                logger.warning("qqbot personality stamp failed", exc_info=True)
            group_only = self.config.bool(
                "participation.group_mention_only", False
            )
            try:
                group_id = str(event.get_group_id() or "")
                policy = self.pipeline._capability_policy(
                    "qqbot_core_reply", group_id=group_id
                )
                if isinstance(policy, dict):
                    override = (policy.get("params") or {}).get(
                        "participation.group_mention_only"
                    )
                    if override is not None:
                        group_only = bool(override)
            except Exception:
                logger.warning("group mention policy lookup failed", exc_info=True)
            if not group_only:
                return
            if self.pipeline.is_private(event):
                return
            if self._has_bot_mention(event):
                return
            # Still observe the message: context and relationship memory must
            # keep flowing even when this message will not be answered.
            self._observe_without_reply(event)
            event.is_at_or_wake_command = False
            event.should_call_llm(False)
            event.stop_event()
            logger.info(
                "group mention hard gate: observed without reply umo=%r",
                str(getattr(event, "unified_msg_origin", "") or ""),
            )
        except Exception:
            logger.exception("group mention hard gate failed")

    def _observe_without_reply(self, event: AstrMessageEvent) -> None:
        """Record a gated group message into chat history without any model call.

        The hard gate stops the event, so the reply pipeline never reaches its
        own ``remember_history``.  Recording here keeps the group's context and
        the identity/relationship view continuous while spending zero tokens.
        """
        try:
            text = str(getattr(event, "message_str", "") or "").strip()
            if text.startswith(("/", "[[", "【")):
                return
            try:
                if str(event.get_sender_id() or "") == str(event.get_self_id() or ""):
                    return
            except Exception:
                pass
            components = self.pipeline.components(event)
            has_image = any(
                self.pipeline.is_component(component, "Image")
                for component in components
            )
            has_face = any(
                self.pipeline.is_component(component, "Face")
                for component in components
            )
            if not text and not has_image and not has_face:
                return
            self.pipeline.remember_history(
                event,
                text,
                has_image=has_image,
                has_face=has_face,
            )
        except Exception:
            logger.warning("observe-without-reply failed", exc_info=True)

    @filter.event_message_type(filter.EventMessageType.ALL, priority=120)
    async def require_mention_for_utility_commands(self, event: AstrMessageEvent):
        """Keep utility commands behind an actual @ in group chats."""
        logger.info(
            "utility mention gate enter: text=%r private=%s umo=%r",
            str(getattr(event, "message_str", "") or ""),
            self.pipeline.is_private(event),
            str(getattr(event, "unified_msg_origin", "") or ""),
        )
        if not self.config.bool("enabled", False):
            return
        if not self.config.bool("utility_commands_require_at", True):
            return
        if self.pipeline.is_private(event):
            return
        owner = _unmentioned_command_owner(str(getattr(event, "message_str", "") or ""))
        if not owner:
            return
        has_mention = self._has_bot_mention(event)
        logger.info(
            "utility mention gate: text=%r owner=%s private=%s self_id=%r has_mention=%s global_require_at=%s",
            str(getattr(event, "message_str", "") or ""),
            owner,
            self.pipeline.is_private(event),
            str(event.get_self_id() or ""),
            has_mention,
            self.config.bool("utility_commands_require_at", True),
        )
        if has_mention:
            return
        event.is_at_or_wake_command = False
        event.stop_event()

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=119)
    @filter.event_message_type(filter.EventMessageType.ALL, priority=119)
    async def allow_unmentioned_utility_commands(self, event: AstrMessageEvent):
        """Allow selected utility commands without @ when their plugin opts in."""
        if not self.config.bool("enabled", False):
            return
        if self.config.bool("utility_commands_require_at", True):
            return
        if self.pipeline.is_private(event):
            return
        owner = _unmentioned_command_owner(str(getattr(event, "message_str", "") or ""))
        if not owner:
            return
        if owner == "qqbot_core_reply":
            allowed = self.config.bool("option_allow_unmentioned", False)
        else:
            getter = getattr(self.context, "get_registered_star", None)
            meta = getter(owner) if callable(getter) else None
            if meta is None or getattr(meta, "activated", True) is False:
                return
            star = getattr(meta, "star_cls", None) or meta
            check = getattr(star, "allow_unmentioned_command", None)
            allowed = bool(check()) if callable(check) else False
        if allowed:
            event.is_at_or_wake_command = True

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=98)
    @filter.event_message_type(filter.EventMessageType.ALL, priority=98)
    async def bare_mention_reply(self, event: AstrMessageEvent):
        """Answer an empty group @ mention without claiming a model turn."""
        if not self.config.bool("enabled", False):
            return
        try:
            if self.pipeline.is_private(event):
                return
            components = list(getattr(getattr(event, "message_obj", None), "message", None) or [])
            if any(type(component).__name__ in {"Image", "Face"} for component in components):
                return
            text_components = [
                str(getattr(component, "text", "") or "")
                for component in components
                if type(component).__name__ == "Text"
            ]
            content_text = "".join(text_components).strip()
            if not text_components:
                content_text = str(getattr(event, "message_str", "") or "").strip()
            if content_text:
                return
            if not (
                self._has_bot_mention(event)
                or bool(getattr(event, "is_at_or_wake_command", False))
            ):
                return
            self.pipeline.block_default_llm(event)
            yield event.plain_result("在呢，怎么啦？")
            event.stop_event()
        except Exception:
            logger.exception("qqbot_core_reply bare mention reply failed")

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=99)
    @filter.event_message_type(filter.EventMessageType.ALL, priority=99)
    async def guard_english_help_phrase(self, event: AstrMessageEvent):
        """Keep ``help me ...`` conversational and enforce the /help switch.

        AstrBot treats an @ mention as a command wake-up, so its built-in
        ``help`` command matches the first word even without a slash.  This
        guard runs before the built-in command and only clears the wake flag
        for the conversational ``help <words>`` form.
        """
        if not self.config.bool("enabled", False):
            return
        text = str(getattr(event, "message_str", "") or "").strip()
        help_enabled = self._help_command_enabled(event)
        if text.startswith(("/", "／")):
            if not help_enabled and re.match(r"(?i)^[/／]help(?:\s|$)", text):
                event.stop_event()
            return
        if re.match(r"(?i)^help(?:\s|$)", text):
            event.is_at_or_wake_command = False
            if not help_enabled:
                event.stop_event()

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=100)
    @filter.event_message_type(filter.EventMessageType.ALL, priority=100)
    async def on_message(self, event: AstrMessageEvent):
        logger.info(
            "event received: umo=%r private=%s text=%r",
            getattr(event, "unified_msg_origin", ""),
            bool(getattr(event, "is_private_chat", lambda: False)()),
            str(getattr(event, "message_str", "") or "")[:60],
        )
        if await self.pipeline.is_duplicate_event(event):
            logger.info("duplicate inbound event ignored: %s", self.pipeline.inbound_key(event))
            return
        outcome = await self.pipeline.handle_message(event)
        if outcome is None:
            return
        for result in outcome.results:
            yield result
        if outcome.turn_id and not outcome.memory_mode:
            self.pipeline.record_delivery(outcome.turn_id, "delivered")
        if outcome.stop:
            event.stop_event()

    @filter.on_llm_request()
    async def inject_memory_mode_context(
        self,
        event: AstrMessageEvent,
        req: Any,
    ) -> None:
        await self.pipeline.handle_memory_context(event, req)

    @filter.on_decorating_result()
    async def decorate_memory_result(self, event: AstrMessageEvent) -> None:
        await self.pipeline.handle_decorating_result(event)

    @filter.after_message_sent()
    async def release_memory_turn_after_send(self, event: AstrMessageEvent) -> None:
        """Release the memory-mode turn even if a higher-priority decorator stops propagation."""
        self.pipeline.release_memory_turn_after_send(event)

    # ------------------------------------------------------------------
    # Canonical commands
    # ------------------------------------------------------------------
    def _group_admin_allowed(self, event: AstrMessageEvent) -> bool:
        star = self.gateway.safe_tools_star()
        checker = getattr(star, "group_admin_override_enabled", None)
        if not callable(checker):
            return False
        try:
            if not bool(checker()):
                return False
        except Exception:
            return False
        sender = getattr(getattr(event, "message_obj", None), "sender", None)
        role = getattr(sender, "role", "")
        if not role and isinstance(sender, dict):
            role = sender.get("role", "")
        # QQ 官方适配器把群成员角色放在 raw_message.author.member_role，
        # AstrBot 的 MessageMember 目前不会带 role；这里直接读取原始事件。
        raw_message = getattr(getattr(event, "message_obj", None), "raw_message", None)
        if not role and raw_message is not None:
            author = raw_message.get("author") if isinstance(raw_message, dict) else getattr(raw_message, "author", None)
            if isinstance(author, dict):
                role = author.get("member_role", "")
            elif author is not None:
                role = getattr(author, "member_role", "") or ""
        if str(role or "").strip().lower() in {"admin", "owner"}:
            return True
        # AstrBot 实例管理员也应能在群里调整测试策略；群管理员开关只控制
        # “普通成员不能改”，不把实例管理员挡在外面。
        allow_bot_admin = getattr(star, "group_admin_allow_bot_admin", None)
        if callable(allow_bot_admin):
            try:
                if not bool(allow_bot_admin()):
                    return False
            except Exception:
                return False
        is_admin = getattr(event, "is_admin", None)
        if callable(is_admin):
            try:
                if bool(is_admin()):
                    return True
            except Exception:
                pass
        # AstrBot 全局 admins_id 中的账号也应可用，避免 QQ 群成员角色
        # 与 AstrBot 实例管理员角色不一致时把人挡在外面。
        sender_id = str(getattr(event, "get_sender_id", lambda: "")() or "")
        sender_name = str(getattr(event, "get_sender_name", lambda: "")() or "")
        if sender_id or sender_name:
            try:
                config = self.context.get_config()
                admins = config.get("admins_id", []) if isinstance(config, dict) else getattr(config, "admins_id", [])
                admin_names = {str(item) for item in (admins or [])}
                if (sender_id and sender_id in admin_names) or (sender_name and sender_name in admin_names):
                    return True
            except Exception:
                pass
        return False

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=110)
    @filter.command("分群", priority=110)
    async def group_policy_command(self, event: AstrMessageEvent):
        event.should_call_llm(True)
        group_id = self.persona._safe_group_id(event)
        if not group_id:
            yield event.plain_result("分群策略只能在群聊里使用。")
            event.stop_event()
            return
        if not self._group_admin_allowed(event):
            yield event.plain_result("只有本群群主/管理员可以在群内修改分群策略；完整配置请到 Studio。")
            event.stop_event()
            return
        star = self.gateway.safe_tools_star()
        if star is None:
            yield event.plain_result("安全工具插件未就绪，暂时不能读取分群策略。")
            event.stop_event()
            return
        raw = str(getattr(event, "message_str", "") or "").strip()
        raw = re.sub(r"^[/／]?分群\s*", "", raw, count=1).strip()
        parts = raw.split()
        action = parts[0] if parts else "状态"
        plugin_id = parts[1] if len(parts) > 1 else ""

        def _scope():
            result = star.policy_scope("group", group_id)
            return result if isinstance(result, dict) else {}

        try:
            if action == "状态":
                data = _scope()
                lines = [
                    f"分群策略 revision {data.get('revision', 0)}",
                    f"本群 ID（官方 openid / OneBot 群号）: {group_id}",
                ]
                plugins = data.get("plugins") if isinstance(data.get("plugins"), dict) else {}
                if not plugins:
                    lines.append("当前使用实例默认，无群级覆盖。")
                for pid, entry in sorted(plugins.items()):
                    enabled = "开" if bool(entry.get("enabled", True)) else "关"
                    params = entry.get("params") if isinstance(entry.get("params"), dict) else {}
                    lines.append(f"{pid}: {enabled}" + (f" · {len(params)} 项覆盖" if params else ""))
                text = "\n".join(lines[:20])
            elif action in {"开启", "关闭"}:
                if not plugin_id:
                    text = "用法：/分群 开启|关闭 <插件ID>"
                else:
                    data = _scope()
                    existing = data.get("plugins", {}).get(plugin_id, {})
                    params = existing.get("params", {}) if isinstance(existing, dict) else {}
                    result = star.policy_set(
                        plugin_id=plugin_id,
                        group_id=group_id,
                        enabled=action == "开启",
                        params=params if isinstance(params, dict) else {},
                        expected_revision=data.get("revision"),
                    )
                    text = f"{plugin_id} 已{action}。" if result.get("ok") else f"设置失败：{result.get('error', 'unknown')}"
            elif action == "重置":
                data = _scope()
                if plugin_id:
                    result = star.policy_reset(
                        plugin_id=plugin_id,
                        group_id=group_id,
                        expected_revision=data.get("revision"),
                    )
                    text = f"{plugin_id} 已重置。" if result.get("ok") else f"重置失败：{result.get('error', 'unknown')}"
                else:
                    result = star.policy_scope_reset(
                        scope_type="group",
                        scope_id=group_id,
                        expected_revision=data.get("revision"),
                    )
                    text = "本群全部覆盖已重置。" if result.get("ok") else f"重置失败：{result.get('error', 'unknown')}"
            elif action == "模板":
                if not plugin_id:
                    text = "用法：/分群 模板 <模板ID>"
                else:
                    data = _scope()
                    result = star.policy_template_apply(
                        group_id=group_id,
                        template_id=plugin_id,
                        expected_revision=data.get("revision"),
                    )
                    text = f"已应用模板 {plugin_id}。" if result.get("ok") else f"应用失败：{result.get('error', 'unknown')}"
            elif action == "概率":
                if not plugin_id:
                    text = "用法：/分群 概率 0.3"
                else:
                    try:
                        probability = float(plugin_id)
                    except ValueError:
                        probability = -1.0
                    if not 0.0 <= probability <= 1.0:
                        text = "概率必须在 0 到 1 之间。"
                    else:
                        data = _scope()
                        result = star.policy_set(
                            plugin_id="qqbot_core_reply",
                            group_id=group_id,
                            enabled=True,
                            params={"participation.reply_probability": probability},
                            expected_revision=data.get("revision"),
                        )
                        text = f"本群非@回复概率已设为 {probability:.2f}。" if result.get("ok") else f"设置失败：{result.get('error', 'unknown')}"
            else:
                text = "用法：/分群 状态|开启 <插件>|关闭 <插件>|重置 [插件]|模板 <ID>|概率 <0..1>"
        except Exception:
            logger.exception("qqbot_core_reply /分群 命令处理失败")
            text = "分群策略操作失败，请稍后到 Studio 重试。"
        yield event.plain_result(text)
        event.stop_event()

    def _option_available(self, plugin_id: str) -> bool:
        if not plugin_id:
            return True
        try:
            return self.context.get_registered_star(plugin_id) is not None
        except Exception:
            return True

    def _option_entries(self) -> list[dict[str, Any]]:
        return [entry for entry in OPTION_COMMANDS if self._option_available(str(entry.get("plugin") or ""))]

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=110)
    @filter.command("option", alias={"插件用法", "用法"}, priority=110)
    async def option_command(self, event: AstrMessageEvent):
        event.should_call_llm(True)
        text = str(getattr(event, "message_str", "") or "").strip()
        parts = text.split(maxsplit=1)
        query = parts[1].strip() if len(parts) > 1 else ""
        entries = self._option_entries()
        if not query:
            lines = ["可用指令："]
            for entry in entries:
                names = "、".join((str(entry["name"]), *entry.get("aliases", ())))
                lines.append(f"/{names} — {entry['summary']}")
            lines.append("")
            lines.append("发送 /option 指令名 查看详细用法。")
            result = "\n".join(lines)
        else:
            wanted = query.lstrip("/／").strip()
            found = next(
                (
                    entry
                    for entry in entries
                    if wanted == entry["name"] or wanted in entry.get("aliases", ())
                ),
                None,
            )
            if found is None:
                result = f"没有找到指令「{wanted}」。发送 /option 查看可用指令。"
            else:
                examples = "\n".join(f"  {item}" for item in found.get("examples", ()))
                result = (
                    f"/{found['name']}\n"
                    f"用途：{found['summary']}\n"
                    f"用法：{found['usage']}\n"
                    f"说明：{found['detail']}"
                )
                if examples:
                    result += f"\n示例：\n{examples}"
        yield event.plain_result(result)
        event.stop_event()

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=110)
    @filter.command("回复", alias={"reply"}, priority=110)
    async def reply_command(self, event: AstrMessageEvent):
        event.should_call_llm(True)
        text = await self.commands.reply_control(event)
        yield event.plain_result(text)
        event.stop_event()

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=110)
    @filter.command("冷却", alias={"cooldown"}, priority=110)
    async def cooldown_command(self, event: AstrMessageEvent):
        event.should_call_llm(True)
        text = await self.commands.cooldown_status(event)
        yield event.plain_result(text)
        event.stop_event()

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=110)
    @filter.command("会话列表", priority=110)
    async def conversation_list_command(self, event: AstrMessageEvent):
        event.should_call_llm(True)
        text = await self.conversation.run_list(event)
        yield event.plain_result(text)
        event.stop_event()

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=110)
    @filter.command("会话", alias={"切换会话"}, priority=110)
    async def conversation_switch_command(self, event: AstrMessageEvent):
        event.should_call_llm(True)
        text = await self.conversation.run_switch(event)
        yield event.plain_result(text)
        event.stop_event()

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=110)
    @filter.command("新会话", priority=110)
    async def conversation_new_command(self, event: AstrMessageEvent):
        event.should_call_llm(True)
        text = await self.conversation.run_new(event)
        yield event.plain_result(text)
        event.stop_event()

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=110)
    @filter.command("删除会话", alias={"会话删除"}, priority=110)
    async def conversation_delete_command(self, event: AstrMessageEvent):
        event.should_call_llm(True)
        text = await self.conversation.run_delete(event)
        yield event.plain_result(text)
        event.stop_event()

    @filter.platform_adapter_type(_PLATFORM_TYPES, priority=110)
    @filter.command("唱歌", alias={"点歌"}, priority=110)
    async def local_song_command(self, event: AstrMessageEvent):
        event.should_call_llm(True)
        reply = await self.commands.song_reply(event)
        if reply.kind == "chain":
            yield event.chain_result(reply.chain)
        else:
            yield event.plain_result(reply.text)
        event.stop_event()

    # ------------------------------------------------------------------
    # Fixed ABI v1 provider methods (delegate to CoreReplyService)
    # ------------------------------------------------------------------
    async def reply_status(self, request_context: Any, args: Any = None):
        return await self.service.reply_status(request_context, args)

    async def reply_configure_plan(self, request_context: Any, args: Any = None):
        return await self.service.reply_configure_plan(request_context, args)

    async def reply_configure_commit(self, request_context: Any, args: Any = None):
        return await self.service.reply_configure_commit(request_context, args)

    async def reply_turn_run(self, request_context: Any, args: Any = None):
        return await self.service.reply_turn_run(request_context, args)

    async def reply_cancel_turn(self, request_context: Any, args: Any = None):
        return await self.service.reply_cancel_turn(request_context, args)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def terminate(self) -> None:
        await self.pipeline.terminate()
        self.state.set_ready(False)
        try:
            self.registry.unregister(PROVIDER_ID, owner=self.owner_token)
        except Exception:
            pass
        self._publish_readiness(False)
